var searchData=
[
  ['doublethresholdfilter',['DoubleThresholdFilter',['../classDoubleThresholdFilter.html',1,'DoubleThresholdFilter'],['../classDoubleThresholdFilter.html#aadb56f9554a7fbb2f61ce6f524905cbf',1,'DoubleThresholdFilter::DoubleThresholdFilter()']]]
];
