var searchData=
[
  ['gaussianblurfilter',['GaussianBlurFilter',['../classGaussianBlurFilter.html',1,'']]],
  ['greyscalefilter',['GreyScaleFilter',['../classGreyScaleFilter.html',1,'']]]
];
