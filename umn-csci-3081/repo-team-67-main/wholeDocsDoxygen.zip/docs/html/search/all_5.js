var searchData=
[
  ['non_2dmax_5fsuppression_2ecc',['non-max_suppression.cc',['../non-max__suppression_8cc.html',1,'']]],
  ['nonmaxsuppressionfilter',['NonMaxSuppressionFilter',['../classNonMaxSuppressionFilter.html',1,'NonMaxSuppressionFilter'],['../classNonMaxSuppressionFilter.html#ae153595697b23839c3f003f8dede7967',1,'NonMaxSuppressionFilter::NonMaxSuppressionFilter()']]]
];
