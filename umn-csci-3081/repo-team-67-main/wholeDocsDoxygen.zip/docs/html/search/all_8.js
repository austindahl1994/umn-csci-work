var searchData=
[
  ['_7efilter',['~Filter',['../classFilter.html#aa37dc017d133404b3a326f363ce36b8a',1,'Filter']]]
];
