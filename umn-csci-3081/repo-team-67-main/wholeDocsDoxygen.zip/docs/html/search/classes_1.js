var searchData=
[
  ['doublethresholdfilter',['DoubleThresholdFilter',['../classDoubleThresholdFilter.html',1,'']]]
];
