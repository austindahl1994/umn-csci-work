var searchData=
[
  ['gaussianblurfilter',['GaussianBlurFilter',['../classGaussianBlurFilter.html#a5b073291df50d87077650371c90af0f9',1,'GaussianBlurFilter']]],
  ['greyscalefilter',['GreyScaleFilter',['../classGreyScaleFilter.html#a39c97682b954a5c00135eb4c13bddd47',1,'GreyScaleFilter::GreyScaleFilter()'],['../classGreyScaleFilter.html#a39c97682b954a5c00135eb4c13bddd47',1,'GreyScaleFilter::GreyScaleFilter()']]]
];
